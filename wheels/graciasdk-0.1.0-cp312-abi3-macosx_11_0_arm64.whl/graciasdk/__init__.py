"""
graciasdk – high-level Python wrapper for the Gracia gaussian-splat rendering SDK.

It wraps the compiled ``pygraciasdk`` extension: create one :class:`GraciaSDK`
(GPU context + renderer), :meth:`~GraciaSDK.load` scenes, and
:meth:`~GraciaSDK.render` them from a :class:`CameraSetup` into NumPy arrays.

Usage::

    from graciasdk import GraciaSDK, camera_from_bbox

    sdk = GraciaSDK(1024, 1024)
    scene = sdk.load("scene.ply")

    result = sdk.render(scene, camera_from_bbox(scene.bbox(), 1024, 1024))
    # result.color: np.ndarray RGBA float16 (H, W, 4), values in [0, 1]
    # result.depth: np.ndarray float32 (H, W) – raw view-space Z, unnormalized, 0 where empty
    # result.mesh_color: np.ndarray RGBA uint8 (H, W, 4) or None

Conventions are right-handed with the camera looking down -Z; matrices are
4x4 column-major ``float32``, and projections are Vulkan-style (depth in
``[0, 1]``, Y flipped).
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional, Sequence, Union

import numpy as np

import pygraciasdk as _native

__all__ = [
    "GraciaSDK",
    "Scene",
    "CameraSetup",
    "RenderResult",
    "camera_from_bbox",
    "camera_from_colmap",
    "look_at",
    "perspective",
    "make_camera",
]


# ── Types ─────────────────────────────────────────────────────────────────────

@dataclass(slots=True)
class CameraSetup:
    """A camera for :meth:`GraciaSDK.render`: a projection plus a pose.

    Both matrices are contiguous ``(4, 4)`` column-major ``float32``. Build one
    with :func:`make_camera`, :func:`camera_from_bbox`, or
    :func:`camera_from_colmap` rather than constructing it directly.
    """
    projection: np.ndarray
    """Projection matrix (clip-from-view), e.g. from :func:`perspective`."""
    camera_transform: np.ndarray
    """Camera-to-world transform (world-from-camera); the inverse of a view matrix."""


@dataclass(slots=True)
class RenderResult:
    """The outputs of a single :meth:`GraciaSDK.render` call."""
    color: np.ndarray
    """RGBA color: ``float16``, shape ``(H, W, 4)``, values in ``[0, 1]``."""
    depth: np.ndarray
    """Per-pixel view-space depth: ``float32``, shape ``(H, W)``.

    The alpha-weighted mean camera-space Z of the splats covering each pixel,
    returned **raw and unnormalized**. Under the right-handed convention the
    camera looks down -Z, so values are negative in front of the camera; pixels
    with no coverage are ``0.0``. Normalize it yourself for display — see the
    gradio example's depth preview.
    """
    mesh_color: Optional[np.ndarray]
    """Mesh overlay: RGBA ``uint8``, shape ``(H, W, 4)``, or ``None``.

    Only video (4DGS) scenes produce a mesh; it is ``None`` for static scenes.
    """


# ── Camera builders ───────────────────────────────────────────────────────────

def look_at(eye: Sequence[float], center: Sequence[float],
            up: Sequence[float] = (0.0, 1.0, 0.0)) -> np.ndarray:
    """Build a right-handed view matrix looking from ``eye`` toward ``center``.

    The camera looks down its local -Z axis, matching the SDK's convention.

    Args:
        eye: World-space camera position ``(x, y, z)``.
        center: World-space point the camera aims at.
        up: Approximate world up direction; need not be perpendicular to the
            view direction.

    Returns:
        A contiguous ``(4, 4)`` column-major ``float32`` view (world-to-camera)
        matrix. Invert it to get the camera-to-world transform
        :func:`make_camera` expects.
    """
    e = np.asarray(eye, dtype=np.float32)
    c = np.asarray(center, dtype=np.float32)
    u = np.asarray(up, dtype=np.float32)
    f = c - e; f /= np.linalg.norm(f)
    s = np.cross(f, u); s /= np.linalg.norm(s)
    u = np.cross(s, f)
    m = np.eye(4, dtype=np.float32)
    m[0, :3] = s;  m[1, :3] = u;  m[2, :3] = -f
    m[0, 3] = -s.dot(e); m[1, 3] = -u.dot(e); m[2, 3] = f.dot(e)
    return np.ascontiguousarray(m.T)


def perspective(fov_y: float, aspect: float, near: float, far: float,
                flip_y: bool = True) -> np.ndarray:
    """Build a Vulkan-style perspective projection matrix.

    Clip space uses depth in ``[0, 1]`` and, with ``flip_y=True``, a negated Y
    axis so the image is upright under Vulkan's top-left origin.

    Args:
        fov_y: Vertical field of view, in radians.
        aspect: Width / height of the render target.
        near: Near clip-plane distance (> 0).
        far: Far clip-plane distance (> ``near``).
        flip_y: Negate the Y axis for Vulkan's coordinate system.

    Returns:
        A contiguous ``(4, 4)`` column-major ``float32`` projection matrix.
    """
    t = math.tan(fov_y * 0.5)
    m = np.zeros((4, 4), dtype=np.float32)
    m[0, 0] = 1.0 / (aspect * t)
    m[1, 1] = (-1.0 if flip_y else 1.0) / t
    m[2, 2] = far / (near - far)
    m[2, 3] = -(far * near) / (far - near)
    m[3, 2] = -1.0
    return np.ascontiguousarray(m.T)


def make_camera(projection: np.ndarray, camera_transform: np.ndarray) -> CameraSetup:
    """Assemble a :class:`CameraSetup` from a projection and a camera pose.

    Both inputs are copied into contiguous ``float32`` as the renderer requires.

    Args:
        projection: ``(4, 4)`` column-major projection, e.g. from
            :func:`perspective`.
        camera_transform: ``(4, 4)`` column-major camera-to-world transform —
            the *inverse* of the view matrix from :func:`look_at`.

    Returns:
        A :class:`CameraSetup` ready for :meth:`GraciaSDK.render`.
    """
    return CameraSetup(
        np.ascontiguousarray(projection, dtype=np.float32),
        np.ascontiguousarray(camera_transform, dtype=np.float32),
    )


def camera_from_bbox(bbox: Sequence[float], width: int, height: int,
                     fov_y: float = math.pi / 2.0) -> CameraSetup:
    """Build a camera that frames an axis-aligned bounding box.

    Positions the camera on the +Z side of the box centre, far enough back that
    the box's bounding sphere fits within ``fov_y`` for the target's aspect
    ratio. A safe default when you just want the whole scene in view.

    Args:
        bbox: ``(min_x, min_y, min_z, max_x, max_y, max_z)``, e.g. from
            :meth:`Scene.bbox`.
        width: Render width in pixels (sets the aspect ratio).
        height: Render height in pixels.
        fov_y: Vertical field of view in radians (default 90°).

    Returns:
        A :class:`CameraSetup` framing the whole box.
    """
    lo = np.array(bbox[:3], dtype=np.float32)
    hi = np.array(bbox[3:], dtype=np.float32)
    center = (lo + hi) * 0.5
    radius = float(np.linalg.norm(hi - lo)) * 0.5
    aspect = width / height
    th = math.tan(fov_y * 0.5)
    dist = max(radius / th, radius / (th * aspect))

    view = look_at(center + [0, 0, dist], center)
    proj = perspective(fov_y, aspect, 0.1, dist + radius * 2.0)
    cam_tf = np.ascontiguousarray(np.linalg.inv(view.T).T, dtype=np.float32)
    return CameraSetup(proj, cam_tf)


def camera_from_colmap(
    qvec: Sequence[float], tvec: Sequence[float],
    fx: float, fy: float, cx: float, cy: float,
    width: int, height: int,
    near: float = 0.01, far: float = 100.0,
) -> CameraSetup:
    """Build a :class:`CameraSetup` from a COLMAP pose and pinhole intrinsics.

    Converts COLMAP's world-to-camera quaternion + translation (Y-down,
    Z-forward) into the SDK's camera-to-world transform (Y-up, Z-backward), and
    turns the pinhole intrinsics into a Vulkan-style projection — reproducing a
    COLMAP view exactly.

    Args:
        qvec: World-to-camera rotation quaternion ``(qw, qx, qy, qz)``.
        tvec: World-to-camera translation ``(tx, ty, tz)``.
        fx: Horizontal focal length in pixels.
        fy: Vertical focal length in pixels.
        cx: Principal-point X in pixels.
        cy: Principal-point Y in pixels.
        width: Image width in pixels.
        height: Image height in pixels.
        near: Near clip-plane distance.
        far: Far clip-plane distance.

    Returns:
        A :class:`CameraSetup` reproducing the COLMAP view.
    """
    qw, qx, qy, qz = qvec
    R = np.array([
        [1-2*qy*qy-2*qz*qz, 2*qx*qy-2*qw*qz,   2*qz*qx+2*qw*qy],
        [2*qx*qy+2*qw*qz,   1-2*qx*qx-2*qz*qz,  2*qy*qz-2*qw*qx],
        [2*qz*qx-2*qw*qy,   2*qy*qz+2*qw*qx,    1-2*qx*qx-2*qy*qy],
    ], dtype=np.float64)

    c2w = np.eye(4, dtype=np.float32)
    c2w[:3, :3] = R.T.astype(np.float32)
    c2w[:3, 3] = (-R.T @ np.asarray(tvec, dtype=np.float64)).astype(np.float32)
    c2w[:3, 1] *= -1  # COLMAP Y-down → OpenGL Y-up
    c2w[:3, 2] *= -1  # COLMAP Z-forward → OpenGL Z-backward

    proj = np.zeros((4, 4), dtype=np.float32)
    proj[0, 0] = 2.0 * fx / width
    proj[1, 1] = -2.0 * fy / height
    proj[0, 2] = 1.0 - 2.0 * cx / width
    proj[1, 2] = 1.0 - 2.0 * cy / height
    proj[2, 2] = far / (near - far)
    proj[2, 3] = -(far * near) / (far - near)
    proj[3, 2] = -1.0

    return CameraSetup(np.ascontiguousarray(proj.T), np.ascontiguousarray(c2w.T))


# ── Scene ─────────────────────────────────────────────────────────────────────

class Scene:
    """A loaded scene: a handle to native splat data plus render-time state.

    Obtain instances from :meth:`GraciaSDK.load`, not by constructing directly.
    A scene is either a static point cloud (``.ply`` / ``.sog`` / ``.guf``) or a
    4DGS video (``.mint``). Methods marked *video only* assume a ``.mint`` scene.
    """
    __slots__ = ("_inner", "_is_video")

    def __init__(self, inner, *, is_video: bool):
        """Wrap a native scene handle. Called by :meth:`GraciaSDK.load`."""
        self._inner = inner
        self._is_video = is_video

    @property
    def is_video(self) -> bool:
        """``True`` for 4DGS video scenes (``.mint``), ``False`` for static ones."""
        return self._is_video

    def bbox(self) -> tuple:
        """Axis-aligned bounds over all splats.

        Returns:
            ``(min_x, min_y, min_z, max_x, max_y, max_z)``.
        """
        return tuple(self._inner.bbox())

    def adaptive_bbox(self) -> tuple:
        """Bounds that discount sparse outlier splats — usually a tighter frame.

        Same 6-tuple layout as :meth:`bbox`; prefer it when floaters would push
        :meth:`bbox` too wide.
        """
        return tuple(self._inner.adaptive_bbox())

    def count(self) -> int:
        """Number of Gaussian splats in the scene."""
        return self._inner.count()

    def set_transform(self, m: np.ndarray):
        """Set the scene's model matrix.

        Args:
            m: ``(4, 4)`` column-major model-to-world transform; copied into
                contiguous ``float32``.
        """
        self._inner.set_transform(np.ascontiguousarray(m, dtype=np.float32))

    def set_flag(self, k: str, v: bool):
        """Toggle a named renderer flag for this scene.

        Args:
            k: Flag name.
            v: Flag value.
        """
        self._inner.set_flag(k, v)

    def duration(self) -> float:
        """Video length in seconds (video only)."""
        return self._inner.duration()

    def set_time(self, t: float):
        """Seek to time ``t`` in seconds (video only)."""
        self._inner.set_time(t)

    def wait_ready(self, timeout: float = 30.0):
        """Block until the first video frames are decoded (video only).

        Args:
            timeout: Seconds to wait before giving up.

        Raises:
            RuntimeError: If decoding is not ready within ``timeout``.
        """
        self._inner.wait_ready(timeout)

    def ready(self) -> bool:
        """Whether the scene is ready to render.

        Always ``True`` for static scenes; for video, the non-blocking poll of
        whether enough frames have decoded.
        """
        return True if not self._is_video else self._inner.ready()


# ── GraciaSDK ────────────────────────────────────────────────────────────────

_IDENTITY = np.eye(4, dtype=np.float32)


class GraciaSDK:
    """GPU context and splats renderer in one. Create once, render many.

    Construction spins up the GPU backend (Metal on macOS, Vulkan elsewhere) and
    allocates render targets at a fixed size, so reuse a single instance across
    many renders. The camera aspect ratio should match ``width / height``.
    """
    __slots__ = ("_sdk", "width", "height")

    def __init__(self, width: int = 4096, height: int = 4096,
                 max_splats_count: int = 16_000_000):
        """Create the GPU context and renderer.

        Args:
            width: Render-target width in pixels (fixed for this instance).
            height: Render-target height in pixels (fixed for this instance).
            max_splats_count: Upper bound on splats drawn in one
                :meth:`render` call, summed across all scenes in the call.
        """
        self._sdk = _native.GraciaSDK(width, height, max_splats_count)
        self.width = width
        self.height = height

    def load(self, path: str) -> Scene:
        """Load a scene file from disk.

        The extension selects the loader: ``.mint`` loads as a 4DGS video
        stream, every other extension (``.ply``, ``.sog``, ``.guf``) as a static
        scene.

        Args:
            path: Path to the scene file.

        Returns:
            A :class:`Scene`. For video, call :meth:`Scene.wait_ready` before the
            first render.

        Raises:
            RuntimeError: If the file cannot be loaded.
        """
        is_video = path.lower().endswith(".mint")
        inner = self._sdk.load(path, is_video)
        return Scene(inner, is_video=is_video)

    def render(
        self,
        objects: Union[Scene, Sequence[Scene]],
        camera: CameraSetup,
        model_transform: Optional[np.ndarray] = None,
    ) -> RenderResult:
        """Render one or more scenes from a camera into NumPy arrays.

        Args:
            objects: A single :class:`Scene` or a sequence of scenes to composite
                into one frame.
            camera: The :class:`CameraSetup` to view from.
            model_transform: Optional ``(4, 4)`` column-major transform applied to
                every scene in the call; identity if ``None``.

        Returns:
            A :class:`RenderResult` with ``color``, ``depth`` (raw view-space Z,
            unnormalized), and an optional ``mesh_color``.
        """
        objs = [objects._inner] if isinstance(objects, Scene) else [o._inner for o in objects]
        r = self._sdk.render(
            objs,
            camera.projection, camera.camera_transform,
            np.ascontiguousarray(model_transform, dtype=np.float32) if model_transform is not None else _IDENTITY,
        )
        color = np.asarray(r.color).view(np.float16)

        raw = np.asarray(r.depth_data)
        alpha = raw[:, :, 1]
        mask = alpha > 1e-6
        depth = np.zeros(alpha.shape, dtype=np.float32)
        depth[mask] = raw[:, :, 0][mask] / alpha[mask]

        return RenderResult(color, depth,
                            np.asarray(r.mesh_color) if r.has_mesh else None)
