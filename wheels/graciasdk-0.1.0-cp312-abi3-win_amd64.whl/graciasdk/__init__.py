"""
graciasdk – high-level Python wrapper for the Gracia gaussian-splat rendering SDK.

It wraps the compiled ``pygraciasdk`` extension: create one :class:`GraciaSDK`
(GPU context + renderer), :meth:`~GraciaSDK.load` scenes, and
:meth:`~GraciaSDK.render` them from a :class:`CameraSetup` into NumPy arrays.

Usage::

    from graciasdk import GraciaSDK, camera_from_bbox

    sdk = GraciaSDK(1024, 1024)
    scene = sdk.load("scene.ply")

    result = sdk.render(scene, camera_from_bbox(scene.bbox(), 1024, 1024))
    # result.color: np.ndarray RGBA float16 (H, W, 4), values in [0, 1]
    # result.depth: np.ndarray float32 (H, W) – raw view-space Z, unnormalized, 0 where empty
    # result.mesh_color: np.ndarray RGBA uint8 (H, W, 4) or None

A ``.mint`` video can also carry the cameras that recorded it::

    scene = sdk.load("clip.mint")
    scene.camera_kinds                       # ("static", ..., "dynamic")
    result = sdk.render(scene, scene.camera("014").at(1.5))

Conventions are right-handed with the camera looking down -Z; matrices are
4x4 column-major ``float32``, and projections are Vulkan-style (depth in
``[0, 1]``, Y flipped).
"""

from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass, field
from typing import Optional, Sequence, Tuple, Union

import numpy as np

import pygraciasdk as _native

__all__ = [
    "GraciaSDK",
    "Scene",
    "SceneCamera",
    "CameraSetup",
    "RenderResult",
    "DEFAULT_FPS",
    "camera_from_bbox",
    "camera_from_colmap",
    "look_at",
    "perspective",
    "make_camera",
]


# ── Types ─────────────────────────────────────────────────────────────────────

@dataclass(slots=True)
class CameraSetup:
    """A camera for :meth:`GraciaSDK.render`: a projection plus a pose.

    Both matrices are contiguous ``(4, 4)`` column-major ``float32``. Build one
    with :func:`make_camera`, :func:`camera_from_bbox`, or
    :func:`camera_from_colmap` rather than constructing it directly.
    """
    projection: np.ndarray
    """Projection matrix (clip-from-view), e.g. from :func:`perspective`."""
    camera_transform: np.ndarray
    """Camera-to-world transform (world-from-camera); the inverse of a view matrix."""


@dataclass(slots=True)
class RenderResult:
    """The outputs of a single :meth:`GraciaSDK.render` call."""
    color: np.ndarray
    """RGBA color: ``float16``, shape ``(H, W, 4)``, values in ``[0, 1]``."""
    depth: np.ndarray
    """Per-pixel view-space depth: ``float32``, shape ``(H, W)``.

    The mean camera-space Z of the splats that cover the pixel, weighted by the
    contribution of each splat to the final color — its alpha times the
    transmittance in front of it. It is **raw and unnormalized**. Under the
    right-handed convention the camera looks down -Z, thus a value in front of
    the camera is negative. A pixel with :attr:`coverage` below ``1/255`` gets
    ``0.0``, which is the threshold that the renderer applies. Normalize it
    yourself for display — see the gradio example's depth preview.
    """
    coverage: np.ndarray
    """Accumulated splat opacity: ``float32``, shape ``(H, W)``, in ``[0, 1]``.

    Multiply a normalized :attr:`depth` by this before you show it. The depth is
    a ratio, thus the division gives a pixel with 2 percent coverage the same
    full-strength value as an opaque pixel, and the edges of an object get a
    hard fringe. The color pass has no such fringe, because a 2 percent pixel
    stays 2 percent bright. This multiplication puts that same falloff back, and
    it is what the renderer does internally.

    Use it also as the mask of the splats, and not the alpha of :attr:`color`,
    which is ``1`` everywhere because the color target clears to opaque black.
    """
    mesh_color: Optional[np.ndarray]
    """Mesh overlay: RGBA ``uint8``, shape ``(H, W, 4)``, or ``None``.

    Only video (4DGS) scenes produce a mesh; it is ``None`` for static scenes.
    """
    buffering: bool = False
    """Whether a video scene had no data for its current time when this drew.

    ``True`` means the image is not the time you asked for: either the frame of
    an earlier time, or an empty frame if nothing had decoded yet. Always
    ``False`` for static scenes. :meth:`GraciaSDK.render` waits for the data by
    default, thus this only turns ``True`` when that wait times out, or when you
    pass ``wait=False``.
    """


# ── Camera builders ───────────────────────────────────────────────────────────

def look_at(eye: Sequence[float], center: Sequence[float],
            up: Sequence[float] = (0.0, 1.0, 0.0)) -> np.ndarray:
    """Build a right-handed view matrix looking from ``eye`` toward ``center``.

    The camera looks down its local -Z axis, matching the SDK's convention.

    Args:
        eye: World-space camera position ``(x, y, z)``.
        center: World-space point the camera aims at.
        up: Approximate world up direction; need not be perpendicular to the
            view direction.

    Returns:
        A contiguous ``(4, 4)`` column-major ``float32`` view (world-to-camera)
        matrix. Invert it to get the camera-to-world transform
        :func:`make_camera` expects.
    """
    e = np.asarray(eye, dtype=np.float32)
    c = np.asarray(center, dtype=np.float32)
    u = np.asarray(up, dtype=np.float32)
    f = c - e; f /= np.linalg.norm(f)
    s = np.cross(f, u); s /= np.linalg.norm(s)
    u = np.cross(s, f)
    m = np.eye(4, dtype=np.float32)
    m[0, :3] = s;  m[1, :3] = u;  m[2, :3] = -f
    m[0, 3] = -s.dot(e); m[1, 3] = -u.dot(e); m[2, 3] = f.dot(e)
    return np.ascontiguousarray(m.T)


def perspective(fov_y: float, aspect: float, near: float, far: float,
                flip_y: bool = True) -> np.ndarray:
    """Build a Vulkan-style perspective projection matrix.

    Clip space uses depth in ``[0, 1]`` and, with ``flip_y=True``, a negated Y
    axis so the image is upright under Vulkan's top-left origin.

    Args:
        fov_y: Vertical field of view, in radians.
        aspect: Width / height of the render target.
        near: Near clip-plane distance (> 0).
        far: Far clip-plane distance (> ``near``).
        flip_y: Negate the Y axis for Vulkan's coordinate system.

    Returns:
        A contiguous ``(4, 4)`` column-major ``float32`` projection matrix.
    """
    t = math.tan(fov_y * 0.5)
    m = np.zeros((4, 4), dtype=np.float32)
    m[0, 0] = 1.0 / (aspect * t)
    m[1, 1] = (-1.0 if flip_y else 1.0) / t
    m[2, 2] = far / (near - far)
    m[2, 3] = -(far * near) / (far - near)
    m[3, 2] = -1.0
    return np.ascontiguousarray(m.T)


def make_camera(projection: np.ndarray, camera_transform: np.ndarray) -> CameraSetup:
    """Assemble a :class:`CameraSetup` from a projection and a camera pose.

    Both inputs are copied into contiguous ``float32`` as the renderer requires.

    Args:
        projection: ``(4, 4)`` column-major projection, e.g. from
            :func:`perspective`.
        camera_transform: ``(4, 4)`` column-major camera-to-world transform —
            the *inverse* of the view matrix from :func:`look_at`.

    Returns:
        A :class:`CameraSetup` ready for :meth:`GraciaSDK.render`.
    """
    return CameraSetup(
        np.ascontiguousarray(projection, dtype=np.float32),
        np.ascontiguousarray(camera_transform, dtype=np.float32),
    )


def camera_from_bbox(bbox: Sequence[float], width: int, height: int,
                     fov_y: float = math.pi / 2.0) -> CameraSetup:
    """Build a camera that frames an axis-aligned bounding box.

    Positions the camera on the +Z side of the box centre, far enough back that
    the box's bounding sphere fits within ``fov_y`` for the target's aspect
    ratio. A safe default when you just want the whole scene in view.

    Args:
        bbox: ``(min_x, min_y, min_z, max_x, max_y, max_z)``, e.g. from
            :meth:`Scene.bbox`.
        width: Render width in pixels (sets the aspect ratio).
        height: Render height in pixels.
        fov_y: Vertical field of view in radians (default 90°).

    Returns:
        A :class:`CameraSetup` framing the whole box.
    """
    lo = np.array(bbox[:3], dtype=np.float32)
    hi = np.array(bbox[3:], dtype=np.float32)
    center = (lo + hi) * 0.5
    radius = float(np.linalg.norm(hi - lo)) * 0.5
    aspect = width / height
    th = math.tan(fov_y * 0.5)
    dist = max(radius / th, radius / (th * aspect))

    view = look_at(center + [0, 0, dist], center)
    proj = perspective(fov_y, aspect, 0.1, dist + radius * 2.0)
    cam_tf = np.ascontiguousarray(np.linalg.inv(view.T).T, dtype=np.float32)
    return CameraSetup(proj, cam_tf)


def _qvec_to_rotmat(qvec: Sequence[float]) -> np.ndarray:
    qw, qx, qy, qz = (float(v) for v in qvec)
    return np.array([
        [1-2*qy*qy-2*qz*qz, 2*qx*qy-2*qw*qz,   2*qz*qx+2*qw*qy],
        [2*qx*qy+2*qw*qz,   1-2*qx*qx-2*qz*qz,  2*qy*qz-2*qw*qx],
        [2*qz*qx-2*qw*qy,   2*qy*qz+2*qw*qx,    1-2*qx*qx-2*qy*qy],
    ], dtype=np.float64)


def camera_from_colmap(
    qvec: Sequence[float], tvec: Sequence[float],
    fx: float, fy: float, cx: float, cy: float,
    width: int, height: int,
    near: float = 0.01, far: float = 100.0,
) -> CameraSetup:
    """Build a :class:`CameraSetup` from a COLMAP pose and pinhole intrinsics.

    Converts COLMAP's world-to-camera quaternion + translation (Y-down,
    Z-forward) into the SDK's camera-to-world transform (Y-up, Z-backward), and
    turns the pinhole intrinsics into a Vulkan-style projection — reproducing a
    COLMAP view exactly.

    Args:
        qvec: World-to-camera rotation quaternion ``(qw, qx, qy, qz)``.
        tvec: World-to-camera translation ``(tx, ty, tz)``.
        fx: Horizontal focal length in pixels.
        fy: Vertical focal length in pixels.
        cx: Principal-point X in pixels.
        cy: Principal-point Y in pixels.
        width: Image width in pixels.
        height: Image height in pixels.
        near: Near clip-plane distance.
        far: Far clip-plane distance.

    Returns:
        A :class:`CameraSetup` reproducing the COLMAP view.
    """
    R = _qvec_to_rotmat(qvec)

    c2w = np.eye(4, dtype=np.float32)
    c2w[:3, :3] = R.T.astype(np.float32)
    c2w[:3, 3] = (-R.T @ np.asarray(tvec, dtype=np.float64)).astype(np.float32)
    c2w[:3, 1] *= -1  # COLMAP Y-down → OpenGL Y-up
    c2w[:3, 2] *= -1  # COLMAP Z-forward → OpenGL Z-backward

    proj = np.zeros((4, 4), dtype=np.float32)
    proj[0, 0] = 2.0 * fx / width
    proj[1, 1] = -2.0 * fy / height
    proj[0, 2] = 1.0 - 2.0 * cx / width
    proj[1, 2] = 1.0 - 2.0 * cy / height
    proj[2, 2] = far / (near - far)
    proj[2, 3] = -(far * near) / (far - near)
    proj[3, 2] = -1.0

    return CameraSetup(np.ascontiguousarray(proj.T), np.ascontiguousarray(c2w.T))


# ── Scene cameras ─────────────────────────────────────────────────────────────

DEFAULT_FPS = 30.0
"""Frame rate that maps a time in seconds to a pose index, if you give none."""

_STATIC = "static"
_DYNAMIC = "dynamic"

_SINGLE_FOCAL_MODELS = frozenset({
    "SIMPLE_PINHOLE", "SIMPLE_RADIAL", "RADIAL",
    "SIMPLE_RADIAL_FISHEYE", "RADIAL_FISHEYE",
})

_LINEAR_SLERP_DOT = 0.9995


@dataclass(frozen=True, slots=True)
class SceneCamera:
    """A camera of the capture rig that the scene file carries.

    A ``.mint`` file can hold the COLMAP cameras that recorded it. A camera with
    one pose is ``"static"``; a camera with one pose for each frame is
    ``"dynamic"``.

    :meth:`GraciaSDK.load` reads and transforms these cameras one time, thus
    :meth:`at` does almost no work. Get them from :attr:`Scene.cameras`.
    """
    name: str
    """Camera name — the stem of the COLMAP image file name, e.g. ``"014"``."""
    kind: str
    """``"static"`` or ``"dynamic"``."""
    model: str
    """COLMAP camera model name, e.g. ``"PINHOLE"``."""
    width: int
    """Source image width in pixels."""
    height: int
    """Source image height in pixels."""
    pinhole: Tuple[float, float, float, float]
    """Intrinsics as ``(fx, fy, cx, cy)``, in pixels.

    A model that holds one focal length reports it as both ``fx`` and ``fy``.
    Distortion parameters do not apply, because the renderer is a pinhole
    renderer.
    """
    qvecs: np.ndarray
    """COLMAP world-to-camera rotations: ``(N, 4)`` ``float32``, scalar-first."""
    tvecs: np.ndarray
    """COLMAP world-to-camera translations: ``(N, 3)`` ``float32``."""

    _projection: np.ndarray = field(repr=False)
    _transforms: np.ndarray = field(repr=False)
    _centers: np.ndarray = field(repr=False)
    _arcs: np.ndarray = field(repr=False)

    @property
    def is_dynamic(self) -> bool:
        """``True`` if the camera moves, thus it holds one pose for each frame."""
        return self.kind == _DYNAMIC

    @property
    def poses_count(self) -> int:
        """Number of stored poses: ``1`` for a static camera, one for each frame
        for a dynamic camera."""
        return self._transforms.shape[0]

    def at(self, time: float = 0.0, fps: float = DEFAULT_FPS) -> CameraSetup:
        """Get the :class:`CameraSetup` of this camera at a time in seconds.

        ``time * fps`` gives the pose index. A static camera always gives its
        single pose. A dynamic camera gives a stored pose at a whole index, and
        interpolates between the two adjacent poses at a fractional index: the
        rotation along the shortest arc, and the position along a straight line.
        A time outside the pose range clamps to the first or the last pose.

        The projection comes from the COLMAP intrinsics, thus the render target
        must have the aspect ratio of :attr:`width` / :attr:`height` for an
        image with no distortion.

        Args:
            time: Time in seconds from the start of the clip. A static camera
                ignores it.
            fps: Frame rate that the poses were captured at.

        Returns:
            A :class:`CameraSetup` for :meth:`GraciaSDK.render`.
        """
        last = self._transforms.shape[0] - 1
        index = 0.0 if last == 0 else float(time) * float(fps)
        if index <= 0.0:
            return CameraSetup(self._projection, self._transforms[0])
        if index >= last:
            return CameraSetup(self._projection, self._transforms[last])

        i = int(index)
        f = index - i
        if f == 0.0:
            return CameraSetup(self._projection, self._transforms[i])

        dot, theta, sin_theta = self._arcs[i].tolist()
        if dot > _LINEAR_SLERP_DOT:
            a, b = 1.0 - f, f
        else:
            a = math.sin(theta - f * theta) / sin_theta
            b = math.sin(f * theta) / sin_theta

        q = self.qvecs[i] * a + self.qvecs[i + 1] * b
        c = self._centers[i]
        return CameraSetup(self._projection, _colmap_transform(
            q / math.sqrt(q @ q), c + f * (self._centers[i + 1] - c)))


def _colmap_transform(qvec: np.ndarray, center: np.ndarray) -> np.ndarray:
    """Build the column-major camera-to-world transform that the renderer wants.

    ``qvec`` is a COLMAP world-to-camera rotation and ``center`` is the world
    position of the camera. Column-major storage is the transpose of the matrix,
    thus each row below is a column of the transform: the rotation transposes
    back to camera-to-world, and rows 1 and 2 negate for the Y-up Z-backward
    convention of the renderer.
    """
    w, x, y, z = qvec.tolist()
    cx, cy, cz = center.tolist()
    xx, yy, zz = 2.0*x*x, 2.0*y*y, 2.0*z*z
    xy, zx, yz = 2.0*x*y, 2.0*z*x, 2.0*y*z
    wx, wy, wz = 2.0*w*x, 2.0*w*y, 2.0*w*z
    return np.array([
        1.0-yy-zz,  xy-wz,       zx+wy,      0.0,
        -(xy+wz),   zz+xx-1.0,   wx-yz,      0.0,
        wy-zx,      -(yz+wx),    yy+xx-1.0,  0.0,
        cx,         cy,          cz,         1.0,
    ], dtype=np.float32).reshape(4, 4)


def _colmap_projection(pinhole: Tuple[float, float, float, float],
                       width: int, height: int,
                       near: float = 0.01, far: float = 100.0) -> np.ndarray:
    fx, fy, cx, cy = pinhole
    proj = np.zeros((4, 4), dtype=np.float32)
    proj[0, 0] = 2.0 * fx / width
    proj[1, 1] = -2.0 * fy / height
    proj[2, 0] = 1.0 - 2.0 * cx / width
    proj[2, 1] = 1.0 - 2.0 * cy / height
    proj[2, 2] = far / (near - far)
    proj[3, 2] = -(far * near) / (far - near)
    proj[2, 3] = -1.0
    return proj


def _camera_centers(qvecs: np.ndarray, tvecs: np.ndarray) -> np.ndarray:
    """World positions of the cameras: ``-R(q) transposed @ t`` for each pose.

    Transposing a rotation is the same as the conjugate quaternion, thus this
    rotates ``t`` by ``(w, -u)`` and needs no rotation matrix.
    """
    w, u = qvecs[:, :1], qvecs[:, 1:]
    ut = np.cross(u, tvecs)
    return -(tvecs - 2.0 * w * ut + 2.0 * np.cross(u, ut))


def _slerp_arcs(qvecs: np.ndarray) -> np.ndarray:
    """Precompute ``(dot, theta, sin theta)`` for each pair of adjacent poses."""
    dots = np.sum(qvecs[:-1] * qvecs[1:], axis=1)
    thetas = np.arccos(np.clip(dots, -1.0, 1.0))
    return np.stack([dots, thetas, np.sin(thetas)], axis=-1)


def _parse_scene_cameras(raw: Union[str, bytes]) -> Tuple[SceneCamera, ...]:
    cameras = []
    for name, entry in sorted(json.loads(raw).items()):
        try:
            extrinsics = entry["extrinsics"]
            intrinsics = entry["intrinsics"]
            tvecs = np.array([p[0] for p in extrinsics], dtype=np.float32).reshape(-1, 3)
            qvecs = np.array([p[1] for p in extrinsics], dtype=np.float32).reshape(-1, 4)
            if len(tvecs) == 0:
                raise ValueError("no extrinsics")
            norms = np.linalg.norm(qvecs, axis=1, keepdims=True)
            if not np.all(norms > 0.0):
                raise ValueError("a quaternion has zero length")
            qvecs = qvecs / norms
            model = str(intrinsics["model"])
            params = tuple(float(v) for v in intrinsics["params"])
            if len(params) < (3 if model in _SINGLE_FOCAL_MODELS else 4):
                raise ValueError(f"{model} needs more parameters than {len(params)}")
            pinhole = ((params[0], params[0], params[1], params[2])
                       if model in _SINGLE_FOCAL_MODELS else params[:4])
            width, height = int(intrinsics["width"]), int(intrinsics["height"])

            # A quaternion and its negative are the same rotation. Aligning the
            # chain one time keeps every interpolation on the shortest arc.
            flip = np.where(np.sum(qvecs[:-1] * qvecs[1:], axis=1) < 0.0, -1.0, 1.0)
            qvecs *= np.concatenate(([1.0], np.cumprod(flip)))[:, None]

            centers = _camera_centers(qvecs, tvecs)
            transforms = np.stack([_colmap_transform(q, c)
                                   for q, c in zip(qvecs, centers)])

            camera = SceneCamera(
                name=str(name),
                kind=_DYNAMIC if len(qvecs) > 1 else _STATIC,
                model=model,
                width=width,
                height=height,
                pinhole=(float(pinhole[0]), float(pinhole[1]),
                         float(pinhole[2]), float(pinhole[3])),
                qvecs=qvecs,
                tvecs=tvecs,
                _projection=_colmap_projection(pinhole, width, height),
                _transforms=transforms,
                _centers=centers,
                _arcs=_slerp_arcs(qvecs),
            )
        except (KeyError, IndexError, TypeError, ValueError) as e:
            raise ValueError(f"Bad camera {name!r} in the CAMERAS chunk: {e}") from e
        cameras.append(camera)
    return tuple(cameras)


# ── Scene ─────────────────────────────────────────────────────────────────────

class Scene:
    """A loaded scene: a handle to native splat data plus render-time state.

    Obtain instances from :meth:`GraciaSDK.load`, not by constructing directly.
    A scene is either a static point cloud (``.ply`` / ``.sog`` / ``.guf``) or a
    4DGS video (``.mint``). Methods marked *video only* assume a ``.mint`` scene.
    """
    __slots__ = ("_inner", "_is_video", "_cameras", "_camera_kinds", "_by_name")

    def __init__(self, inner, *, is_video: bool,
                 cameras: Sequence[SceneCamera] = ()):
        """Wrap a native scene handle. Called by :meth:`GraciaSDK.load`."""
        self._inner = inner
        self._is_video = is_video
        self._cameras = tuple(cameras)
        self._camera_kinds = tuple(c.kind for c in self._cameras)
        self._by_name = {c.name: c for c in self._cameras}

    @property
    def is_video(self) -> bool:
        """``True`` for 4DGS video scenes (``.mint``), ``False`` for static ones."""
        return self._is_video

    @property
    def cameras(self) -> Tuple[SceneCamera, ...]:
        """The cameras that the file carries, sorted by name.

        :meth:`GraciaSDK.load` reads and transforms them one time, thus this is
        a plain attribute read, and ``len(scene.cameras)`` is their count. It is
        empty for a static scene and for a video with no camera data.
        """
        return self._cameras

    @property
    def camera_kinds(self) -> Tuple[str, ...]:
        """Kind of each camera: ``"static"`` or ``"dynamic"``.

        The order matches :attr:`cameras`, thus index ``i`` is the kind of
        camera ``i``.
        """
        return self._camera_kinds

    def camera(self, key: Union[int, str]) -> SceneCamera:
        """Get one camera by name or by index.

        Args:
            key: A camera name, or an index into :attr:`cameras`.

        Returns:
            The :class:`SceneCamera`. Call :meth:`SceneCamera.at` on it to get a
            camera to render with.

        Raises:
            KeyError: If no camera has that name.
            IndexError: If the index is out of range.
        """
        if isinstance(key, str):
            try:
                return self._by_name[key]
            except KeyError:
                raise KeyError(f"No camera named {key!r}") from None
        return self._cameras[key]

    def _ensure_ready(self, timeout: float = 30.0):
        """Block until the stream is ready (video only).

        A getter that needs the scene gives an empty box before that.
        """
        if self._is_video and not self._inner.ready():
            self._inner.wait_ready(timeout)

    def bbox(self) -> tuple:
        """Axis-aligned bounds over all splats.

        For a video it waits for the stream to be ready, thus it can block. Call
        :meth:`wait_ready` first to control that wait yourself.

        Returns:
            ``(min_x, min_y, min_z, max_x, max_y, max_z)``.

        Raises:
            RuntimeError: If the first frame does not decode in 30 seconds.
        """
        self._ensure_ready()
        return tuple(self._inner.bbox())

    def adaptive_bbox(self) -> tuple:
        """Bounds that discount sparse outlier splats — usually a tighter frame.

        Same 6-tuple layout as :meth:`bbox`, and it waits the same way; prefer
        it when floaters would push :meth:`bbox` too wide.
        """
        self._ensure_ready()
        return tuple(self._inner.adaptive_bbox())

    def count(self) -> int:
        """Number of Gaussian splats in the scene.

        For a video this is the count of the frame that was drawn last, thus it
        is ``0`` until the first :meth:`GraciaSDK.render`, and it changes as the
        video plays.
        """
        return self._inner.count()

    def set_transform(self, m: np.ndarray):
        """Set the scene's model matrix.

        Args:
            m: ``(4, 4)`` column-major model-to-world transform; copied into
                contiguous ``float32``.
        """
        self._inner.set_transform(np.ascontiguousarray(m, dtype=np.float32))

    def set_flag(self, k: str, v: bool):
        """Toggle a named renderer flag for this scene.

        Args:
            k: Flag name.
            v: Flag value.
        """
        self._inner.set_flag(k, v)

    def set_uint(self, k: str, v: int):
        """Set a named unsigned-integer parameter for this scene.

        Known keys:

        ``instance_filter``
            Highlight the splats whose segmentation instance id equals ``v``:
            they are drawn white and every other splat black; ``0`` disables
            the highlight and keeps the original colors. Only MINT v6 video
            carries instance ids — see :meth:`instance_names` for the ids a
            scene actually has.

        Args:
            k: Parameter name.
            v: Parameter value.
        """
        self._inner.set_uint(k, v)

    def instance_names(self) -> dict:
        """Segmentation classes stored in the file (video only).

        Returns:
            ``{instance_id: name}`` for every labelled instance, or an empty
            dict for a static scene or a video with no segmentation. Pass an id
            to :meth:`set_uint` as ``instance_filter`` to highlight that
            instance.
        """
        return dict(self._inner.instance_names()) if self._is_video else {}

    def duration(self) -> float:
        """Video length in seconds (video only)."""
        return self._inner.duration()

    def set_time(self, t: float):
        """Seek to time ``t`` in seconds (video only).

        The seek is not instant: the decoder fetches and uploads a chunk over
        several turns, so the data for ``t`` is usually not on the GPU when this
        returns — see :meth:`is_buffering`. :meth:`GraciaSDK.render` waits for it
        by default, thus you only need :meth:`wait_buffered` yourself if you
        render with ``wait=False``.
        """
        self._inner.set_time(t)

    def wait_ready(self, timeout: float = 30.0):
        """Block until the first video frames are decoded (video only).

        Args:
            timeout: Seconds to wait before giving up.

        Raises:
            RuntimeError: If decoding is not ready within ``timeout``.
        """
        self._inner.wait_ready(timeout)

    def ready(self) -> bool:
        """Whether the scene has decoded its first frame.

        Always ``True`` for static scenes. For video it stays ``True`` after the
        first frame, thus it does not tell you that a later seek has data. Use
        :meth:`is_buffering` for that.
        """
        return True if not self._is_video else self._inner.ready()

    def is_buffering(self) -> bool:
        """Whether the scene has no data for the current time (video only).

        A seek with :meth:`set_time` can land in a part of the clip that is not
        decoded yet. A render in that state gives an empty or an old frame, thus
        check this first, or call :meth:`wait_buffered`. Always ``False`` for a
        static scene.
        """
        return False if not self._is_video else self._inner.is_buffering()

    def wait_buffered(self, timeout: float = 5.0, poll: float = 0.001) -> bool:
        """Block while the scene buffers, and give the outcome (video only).

        :meth:`GraciaSDK.render` does this for you unless you pass ``wait=False``;
        call it yourself when you want the outcome before you commit to a render.

        Args:
            timeout: Seconds to wait before it gives up.
            poll: Seconds between the checks.

        Returns:
            ``True`` when the data for the current time is ready, ``False`` if
            ``timeout`` passed first. It does not raise, thus a render loop can
            skip a frame and continue.
        """
        if not self._is_video:
            return True
        deadline = time.monotonic() + timeout
        while self._inner.is_buffering():
            if time.monotonic() >= deadline:
                return False
            time.sleep(poll)
        return True


# ── GraciaSDK ────────────────────────────────────────────────────────────────

_IDENTITY = np.eye(4, dtype=np.float32)

_MIN_COVERAGE = 1.0 / 255.0
"""Coverage below this gives no depth. The renderer uses the same threshold."""


class GraciaSDK:
    """GPU context and splats renderer in one. Create once, render many.

    Construction spins up the GPU backend (Metal on macOS, Vulkan elsewhere) and
    allocates render targets at a fixed size, so reuse a single instance across
    many renders. The camera aspect ratio should match ``width / height``.
    """
    __slots__ = ("_sdk", "width", "height")

    def __init__(self, width: int = 4096, height: int = 4096,
                 max_splats_count: int = 16_000_000):
        """Create the GPU context and renderer.

        Args:
            width: Render-target width in pixels (fixed for this instance).
            height: Render-target height in pixels (fixed for this instance).
            max_splats_count: Upper bound on splats drawn in one
                :meth:`render` call, summed across all scenes in the call.
        """
        self._sdk = _native.GraciaSDK(width, height, max_splats_count)
        self.width = width
        self.height = height

    def load(self, path: str) -> Scene:
        """Load a scene file from disk.

        The extension selects the loader: ``.mint`` loads as a 4DGS video
        stream, every other extension (``.ply``, ``.sog``, ``.guf``) as a static
        scene. A video that carries camera data gets it parsed and transformed
        here, thus :attr:`Scene.cameras` is ready when this call returns.

        Args:
            path: Path to the scene file.

        Returns:
            A :class:`Scene`. For video, call :meth:`Scene.wait_ready` before the
            first render.

        Raises:
            RuntimeError: If the file cannot be loaded.
            ValueError: If the camera data of the file is bad.
        """
        is_video = path.lower().endswith(".mint")
        inner = self._sdk.load(path, is_video)
        cameras = ()
        if is_video:
            raw = inner.cameras_json()
            if raw:
                cameras = _parse_scene_cameras(raw)
        return Scene(inner, is_video=is_video, cameras=cameras)

    def render(
        self,
        objects: Union[Scene, Sequence[Scene]],
        camera: CameraSetup,
        model_transform: Optional[np.ndarray] = None,
        wait: Union[bool, float] = True,
    ) -> RenderResult:
        """Render one or more scenes from a camera into NumPy arrays.

        For a video scene this waits, by default, until the data for the time
        that :meth:`Scene.set_time` asked for has decoded, because the decoder
        needs several turns to fetch and upload a frame. Without that wait the
        image is the *previous* time, or empty before the first frame decodes.
        :attr:`RenderResult.buffering` reports whether that happened.

        Args:
            objects: A single :class:`Scene` or a sequence of scenes to composite
                into one frame.
            camera: The :class:`CameraSetup` to view from.
            model_transform: Optional ``(4, 4)`` column-major transform applied to
                every scene in the call; identity if ``None``.
            wait: Seconds to wait for each video scene, ``True`` for the 5 second
                default, or ``False`` to draw whatever has decoded so far and
                report it in :attr:`RenderResult.buffering`. A timeout does not
                raise, thus a render loop can skip the frame and go on.

        Returns:
            A :class:`RenderResult` with ``color``, ``depth`` (raw view-space Z,
            unnormalized), ``coverage``, an optional ``mesh_color``, and
            ``buffering``.

        Raises:
            RuntimeError: If a video scene does not decode its first frame within
                30 seconds, when ``wait`` is not ``False``.
        """
        scenes = [objects] if isinstance(objects, Scene) else list(objects)
        if wait is not False:
            timeout = 5.0 if wait is True else float(wait)
            for s in scenes:
                if s.is_video:
                    s._ensure_ready()
                    s.wait_buffered(timeout)
        objs = [s._inner for s in scenes]
        r = self._sdk.render(
            objs,
            camera.projection, camera.camera_transform,
            np.ascontiguousarray(model_transform, dtype=np.float32) if model_transform is not None else _IDENTITY,
        )
        color = np.asarray(r.color).view(np.float16)

        raw = np.asarray(r.depth_data)
        coverage = np.ascontiguousarray(raw[:, :, 1])
        depth = np.zeros_like(coverage)
        np.divide(raw[:, :, 0], coverage, out=depth, where=coverage >= _MIN_COVERAGE)

        return RenderResult(color, depth, coverage,
                            np.asarray(r.mesh_color) if r.has_mesh else None,
                            r.buffering)
