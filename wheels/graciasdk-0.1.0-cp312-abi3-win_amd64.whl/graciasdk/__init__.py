"""Render Gaussian splat scenes on the GPU into NumPy arrays.

Usage::

    from graciasdk import GraciaSDK

    sdk = GraciaSDK()
    scene = sdk.load("path/to/video")
    view = sdk.view(scene, scene.camera("014"), 1024, 1024, time=1.5)
    view.color8     # RGBA uint8 (H, W, 4), rendered now
    view.time = 1.6
    view.depth      # float32 (H, W), rendered for the new time; the colour renders again only when asked

The state lives here, in Python; the native module renders one output when asked and reads it back.

Matrices are 4x4 column-major ``float32``, right-handed with the camera looking
down -Z. A projection is Vulkan style: depth in ``[0, 1]``, Y flipped.
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Callable, Optional, Sequence, Tuple, Union

import numpy as np

import pygraciasdk as _native

__all__ = [
    "GraciaSDK",
    "Scene",
    "SceneCamera",
    "PointCloud",
    "CameraSetup",
    "View",
    "FlowResult",
    "camera_from_bbox",
    "camera_from_colmap",
    "look_at",
    "perspective",
    "make_camera",
    "draw_points",
    "flow_colors",
    "draw_flow_arrows",
    "HAND_EDGES",
]


# ── Types ─────────────────────────────────────────────────────────────────────

@dataclass(slots=True)
class CameraSetup:
    """A projection and a camera-to-world transform, each a contiguous ``(4, 4)`` column-major ``float32``."""
    projection: np.ndarray
    camera_transform: np.ndarray


@dataclass(slots=True)
class FlowResult:
    """The output of one :meth:`View.flow`."""
    flow: np.ndarray
    """``float32`` ``(H, W, 2)``: the move in pixels, x right and y down the image rows, from where each splat is at the time to where it is at the reference time, both seen from the camera; 0 under ``1/255`` :attr:`coverage`. A pixel ``(x, y)`` moves to ``(x + flow[..., 0], y + flow[..., 1])``."""
    coverage: np.ndarray
    """``float32`` ``(H, W)`` in ``[0, 1]``: the accumulated opacity of the splats at both times, the splats that :attr:`flow` measures."""
    buffering: bool = False
    """``True`` when a video had no data for one of the two times: the flow measures an earlier time."""


# ── Camera builders ───────────────────────────────────────────────────────────

def look_at(eye: Sequence[float], center: Sequence[float],
            up: Sequence[float] = (0.0, 1.0, 0.0)) -> np.ndarray:
    """A right-handed view (world-to-camera) matrix from ``eye`` toward ``center``."""
    e, c, u = (np.asarray(v, dtype=np.float32) for v in (eye, center, up))
    f = (c - e) / np.linalg.norm(c - e)
    s = np.cross(f, u)
    s /= np.linalg.norm(s)
    u = np.cross(s, f)
    m = np.eye(4, dtype=np.float32)
    m[0, :3], m[1, :3], m[2, :3] = s, u, -f
    m[:3, 3] = -s.dot(e), -u.dot(e), f.dot(e)
    return np.ascontiguousarray(m.T)


def perspective(fov_y: float, aspect: float, near: float, far: float,
                flip_y: bool = True) -> np.ndarray:
    """A projection with ``fov_y`` in radians, depth in ``[0, 1]``, and Y negated unless ``flip_y`` is ``False``."""
    t = math.tan(fov_y * 0.5)
    m = np.zeros((4, 4), dtype=np.float32)
    m[0, 0] = 1.0 / (aspect * t)
    m[1, 1] = (-1.0 if flip_y else 1.0) / t
    m[2, 2] = far / (near - far)
    m[2, 3] = -(far * near) / (far - near)
    m[3, 2] = -1.0
    return np.ascontiguousarray(m.T)


def make_camera(projection: np.ndarray, camera_transform: np.ndarray) -> CameraSetup:
    """A :class:`CameraSetup` of a projection and a camera-to-world transform, the inverse of a view matrix."""
    return CameraSetup(np.ascontiguousarray(projection, dtype=np.float32),
                       np.ascontiguousarray(camera_transform, dtype=np.float32))


def camera_from_bbox(bbox: Sequence[float], width: int, height: int,
                     fov_y: float = math.pi / 2.0) -> CameraSetup:
    """A camera on the +Z side of ``(min_x, min_y, min_z, max_x, max_y, max_z)`` that frames all of the box."""
    lo, hi = np.asarray(bbox[:3], dtype=np.float32), np.asarray(bbox[3:], dtype=np.float32)
    center = (lo + hi) * 0.5
    radius = float(np.linalg.norm(hi - lo)) * 0.5
    aspect = width / height
    th = math.tan(fov_y * 0.5)
    dist = max(radius / th, radius / (th * aspect))
    view = look_at(center + [0, 0, dist], center)
    return make_camera(perspective(fov_y, aspect, 0.1, dist + radius * 2.0), np.linalg.inv(view.T).T)


def camera_from_colmap(
    qvec: Sequence[float], tvec: Sequence[float],
    fx: float, fy: float, cx: float, cy: float,
    width: int, height: int,
    near: float = 0.01, far: float = 100.0,
) -> CameraSetup:
    """The camera of a COLMAP view: a world-to-camera ``qvec`` ``(qw, qx, qy, qz)`` and ``tvec``, and pinhole intrinsics in pixels."""
    q = np.asarray(qvec, dtype=np.float64)
    q = q / np.linalg.norm(q)
    center = _centers(q[None], np.asarray(tvec, dtype=np.float64)[None])[0]
    return CameraSetup(_projection((fx, fy, cx, cy), width, height, near, far), _transform(q, center))


def _transform(qvec: np.ndarray, center: np.ndarray) -> np.ndarray:
    """The camera-to-world transform of a COLMAP rotation ``(w, x, y, z)`` at a world position; each row is a column, Y and Z negated."""
    w, x, y, z = qvec.tolist()
    xx, yy, zz = 2.0*x*x, 2.0*y*y, 2.0*z*z
    xy, zx, yz = 2.0*x*y, 2.0*z*x, 2.0*y*z
    wx, wy, wz = 2.0*w*x, 2.0*w*y, 2.0*w*z
    return np.array([
        [1.0-yy-zz,  xy-wz,      zx+wy,      0.0],
        [-(xy+wz),   zz+xx-1.0,  wx-yz,      0.0],
        [wy-zx,      -(yz+wx),   yy+xx-1.0,  0.0],
        [*center.tolist(),                   1.0],
    ], dtype=np.float32)


def _projection(pinhole: Sequence[float], width: int, height: int,
                near: float = 0.01, far: float = 100.0) -> np.ndarray:
    """The column-major projection of pinhole intrinsics ``(fx, fy, cx, cy)``."""
    fx, fy, cx, cy = pinhole
    m = np.zeros((4, 4), dtype=np.float32)
    m[0, 0] = 2.0 * fx / width
    m[1, 1] = -2.0 * fy / height
    m[2, 0] = 1.0 - 2.0 * cx / width
    m[2, 1] = 1.0 - 2.0 * cy / height
    m[2, 2] = far / (near - far)
    m[2, 3] = -1.0
    m[3, 2] = -(far * near) / (far - near)
    return m


def _centers(qvecs: np.ndarray, tvecs: np.ndarray) -> np.ndarray:
    """The world position of each camera, ``-R(q)^T t``: ``t`` turned by the conjugate quaternion."""
    w, u = qvecs[:, :1], qvecs[:, 1:]
    ut = np.cross(u, tvecs)
    return -(tvecs - 2.0 * w * ut + 2.0 * np.cross(u, ut))


def _frame(time: float, count: int, begin: float, end: float) -> Tuple[int, int, float]:
    """The two neighbour frames of ``count`` spread evenly over ``[begin, end)`` at ``time``, and how far between them."""
    last, span = count - 1, end - begin
    x = min(max((time - begin) * count / span, 0.0), last) if last > 0 and span > 0 else 0.0
    i = int(x)
    return i, min(i + 1, last), x - i


def _slerp(a: np.ndarray, b: np.ndarray, f: float) -> np.ndarray:
    """The unit quaternion ``f`` of the way from ``a`` to ``b``, two neighbours on the shortest arc."""
    dot = float(a @ b)
    if dot > 0.9995:
        q = a + f * (b - a)
    else:
        theta = math.acos(dot)
        q = (math.sin((1.0 - f) * theta) * a + math.sin(f * theta) * b) / math.sin(theta)
    return q / math.sqrt(float(q @ q))


# ── Scene cameras ─────────────────────────────────────────────────────────────

_SINGLE_FOCAL_MODELS = frozenset({
    "SIMPLE_PINHOLE", "SIMPLE_RADIAL", "RADIAL", "SIMPLE_RADIAL_FISHEYE",
    "RADIAL_FISHEYE", "SIMPLE_DIVISION", "SIMPLE_FISHEYE",
})


@dataclass(frozen=True, slots=True)
class SceneCamera:
    """A camera that recorded a video; get it from :attr:`Scene.cameras`."""
    name: str
    """The stem of the COLMAP image name, for example ``"014"``."""
    kind: str
    """``"static"``, one pose, or ``"dynamic"``, one pose for each frame spread evenly over the track."""
    model: str
    """The COLMAP camera model, for example ``"PINHOLE"``."""
    width: int
    """The width of the source image in pixels."""
    height: int
    """The height of the source image in pixels."""
    pinhole: Tuple[float, float, float, float]
    """``(fx, fy, cx, cy)`` in pixels; a model with one focal length gives it twice, and distortion does not apply."""
    qvecs: np.ndarray
    """``(N, 4)`` ``float32`` world-to-camera rotations, scalar first."""
    tvecs: np.ndarray
    """``(N, 3)`` ``float32`` world-to-camera translations."""

    _projection: np.ndarray = field(repr=False)
    _centers: np.ndarray = field(repr=False)
    _begin: float = field(repr=False)
    _end: float = field(repr=False)

    @property
    def is_dynamic(self) -> bool:
        return self.kind == "dynamic"

    @property
    def poses_count(self) -> int:
        return len(self.qvecs)

    def at(self, time: float = 0.0) -> CameraSetup:
        """The camera at ``time`` seconds, the time that :meth:`Scene.set_time` takes.

        Pose ``i`` is at ``begin + i * (end - begin) / poses_count``, where ``begin`` and ``end`` are the extent of the
        track. Between two poses the rotation turns along the shortest arc and the position moves along a line, and a
        time outside the poses clamps to the nearest one. Render at the aspect ratio of ``width / height`` for an image
        with no distortion.
        """
        i, j, f = _frame(time, len(self.qvecs), self._begin, self._end)
        center = self._centers[i] + f * (self._centers[j] - self._centers[i])
        return CameraSetup(self._projection, _transform(_slerp(self.qvecs[i], self.qvecs[j], f), center))


def _scene_camera(begin: float, end: float, name: str, kind: str, model: str, width: int, height: int,
                  params: Sequence[float], poses: Sequence[Sequence[float]]) -> SceneCamera:
    """A camera of the native reader, each pose ``(tx, ty, tz, qx, qy, qz, qw)``; a camera that cannot draw raises."""
    poses = np.asarray(poses, dtype=np.float32).reshape(-1, 7)
    qvecs = poses[:, [6, 3, 4, 5]]
    norms = np.linalg.norm(qvecs, axis=1, keepdims=True)
    single = model in _SINGLE_FOCAL_MODELS
    why = ("no pose" if len(poses) == 0 else
           "a quaternion has zero length" if not np.all(norms > 0.0) else
           "no camera model that this build knows" if not model else
           f"{model} needs more parameters than {len(params)}" if len(params) < (3 if single else 4) else "")
    if why:
        raise ValueError(f"Bad camera {name!r} in the file: {why}")

    # A quaternion and its negative are one rotation: the chain is aligned once, so every slerp takes the shortest arc.
    qvecs = qvecs / norms
    qvecs *= np.concatenate(([1.0], np.cumprod(np.where(np.sum(qvecs[:-1] * qvecs[1:], axis=1) < 0.0, -1.0, 1.0))))[:, None]

    pinhole = tuple(float(p) for p in ((params[0], params[0], params[1], params[2]) if single else params[:4]))
    tvecs = np.ascontiguousarray(poses[:, :3])
    return SceneCamera(name, kind, model, width, height, pinhole, qvecs, tvecs,
                       _projection(pinhole, width, height), _centers(qvecs, tvecs), begin, end)


# ── Point clouds ──────────────────────────────────────────────────────────────

@dataclass(frozen=True, slots=True)
class PointCloud:
    """A named point cloud of a video's track, one set of points a frame; get it from :attr:`Scene.point_clouds`."""
    name: str
    positions: np.ndarray
    """``(F, N, 3)`` ``float32`` world positions, the frames spread evenly over the track; NaN where a frame has no data."""

    _begin: float = field(repr=False)
    _end: float = field(repr=False)

    def at(self, time: float = 0.0) -> np.ndarray:
        """The ``(N, 3)`` points at ``time`` seconds: frame ``i`` of ``F`` is at ``begin + i * (end - begin) / F``.

        Between two frames each point moves along a line, and a point with no data in either frame is NaN; a time
        outside the frames clamps to the nearest one.
        """
        i, j, f = _frame(time, len(self.positions), self._begin, self._end)
        a = self.positions[i]
        return a if f == 0.0 else a + f * (self.positions[j] - a)


HAND_EDGES = (
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (0, 9), (9, 10), (10, 11), (11, 12),
    (0, 13), (13, 14), (14, 15), (15, 16),
    (0, 17), (17, 18), (18, 19), (19, 20),
)
"""The bones of a hand of 21 keypoints, the wrist then four joints a finger from the thumb, for :func:`draw_points`."""


def draw_points(image: np.ndarray, camera: CameraSetup, points: np.ndarray, edges: Sequence[Tuple[int, int]] = (),
                color: Sequence[float] = (1.0, 0.25, 0.25), square: int = 6, line: int = 2) -> np.ndarray:
    """Draw world ``points`` ``(N, 3)`` seen from ``camera`` into ``image`` ``(H, W, C)`` in place, and give it back.

    Each point is a ``square`` pixels wide square and each ``(a, b)`` of ``edges`` a ``line`` pixels wide line.
    ``color`` is RGB in ``[0, 1]``, scaled to 255 for an integer image, and a fourth channel is made opaque. A NaN
    point, or one behind the camera, draws nothing.
    """
    height, width = image.shape[:2]
    full = 255.0 if np.issubdtype(image.dtype, np.integer) else 1.0
    ink = np.append(np.asarray(color, dtype=np.float64) * full, full)[:image.shape[2]]
    pixels = _pixels(camera, np.asarray(points, dtype=np.float64), width, height)
    for a, b in edges:
        _stamp(image, _line(pixels[a], pixels[b], width, height), line, ink)
    _stamp(image, pixels[~np.isnan(pixels).any(axis=1)], square, ink)
    return image


def _pixels(camera: CameraSetup, points: np.ndarray, width: int, height: int) -> np.ndarray:
    """Where world points land in an image of ``width`` by ``height``, ``(N, 2)`` pixels, NaN behind the camera."""
    view = np.linalg.inv(camera.camera_transform.astype(np.float64))   # column-major, so rows multiply on the left
    clip = np.c_[points, np.ones(len(points))] @ view @ camera.projection.astype(np.float64)
    w = clip[:, 3:]
    with np.errstate(invalid="ignore", divide="ignore"):
        ndc = np.where(w > 0.0, clip[:, :2] / w, np.nan)
    return (ndc + 1.0) * 0.5 * (width, height)


def _clip(a: np.ndarray, b: np.ndarray, width: int, height: int) -> Optional[Tuple[np.ndarray, np.ndarray]]:
    """The part of the segment from ``a`` to ``b`` inside the image, clipped against each side, or ``None``."""
    if np.isnan(a).any() or np.isnan(b).any():
        return None
    d, t0, t1 = b - a, 0.0, 1.0
    for p, q in ((-d[0], a[0]), (d[0], width - 1 - a[0]), (-d[1], a[1]), (d[1], height - 1 - a[1])):
        if p == 0.0:
            if q < 0.0:
                return None
        elif p < 0.0:
            t0 = max(t0, q / p)
        else:
            t1 = min(t1, q / p)
    return (a + t0 * d, a + t1 * d) if t0 <= t1 else None


def _line(a: np.ndarray, b: np.ndarray, width: int, height: int) -> np.ndarray:
    """The pixel centres ``(K, 2)`` one pixel apart along the part of the segment from ``a`` to ``b`` inside the image."""
    if not (segment := _clip(a, b, width, height)):
        return np.empty((0, 2))
    return np.linspace(segment[0], segment[1], int(np.ceil(np.abs(segment[1] - segment[0]).max())) + 1)


def _stamp(image: np.ndarray, centers: np.ndarray, size: int, ink: np.ndarray) -> None:
    """Fill a ``size`` pixel square around each of ``centers`` ``(K, 2)``, the parts inside the image, in one ``ink`` or one for each centre ``(K, C)``."""
    offsets = np.arange(size) - (size - 1) // 2
    x = (np.rint(centers[:, 0])[:, None, None] + offsets[None, None, :]).astype(np.int64)
    y = (np.rint(centers[:, 1])[:, None, None] + offsets[None, :, None]).astype(np.int64)
    x, y = np.broadcast_arrays(x, y)
    inside = (x >= 0) & (x < image.shape[1]) & (y >= 0) & (y < image.shape[0])
    ink = np.asarray(ink)
    image[y[inside], x[inside]] = np.broadcast_to(ink if ink.ndim == 1 else ink[:, None, None], x.shape + ink.shape[-1:])[inside]


# ── Flow ──────────────────────────────────────────────────────────────────────

def _wheel() -> np.ndarray:
    """The 55 colours of the Middlebury wheel in ``[0, 1]``: red to yellow, green, cyan, blue, magenta and back, in 15, 6, 4, 11, 13 and 6 steps."""
    parts = []
    for steps, full, channel, rises in ((15, 0, 1, True), (6, 1, 0, False), (4, 1, 2, True),
                                         (11, 2, 1, False), (13, 2, 0, True), (6, 0, 2, False)):
        ramp = np.floor(255 * np.arange(steps) / steps)
        part = np.zeros((steps, 3))
        part[:, full] = 255
        part[:, channel] = ramp if rises else 255 - ramp
        parts.append(part)
    return (np.concatenate(parts) / 255.0).astype(np.float32)


_WHEEL = _wheel()


def flow_colors(flow: np.ndarray, coverage: np.ndarray, scale: float = 0.0) -> Tuple[np.ndarray, float]:
    """RGB ``uint8`` ``(H, W, 3)`` of :attr:`FlowResult.flow` on the Middlebury colour wheel, and the scale it used.

    The hue is the direction of the move. A move of ``scale`` pixels or more is full colour, and no move is white.
    ``scale`` 0 takes the 95th percentile of the moves over the pixels with ``coverage`` above 0.01, or 1 when none
    moves. Each colour is multiplied by its pixel's ``coverage``, so edges fade to black as depth does for display. A
    pixel with ``coverage`` at 0.01 or below, or with a move that is not finite, is black.
    """
    moves = np.asarray(flow, dtype=np.float32)
    magnitude = np.hypot(moves[..., 0], moves[..., 1])
    valid = (coverage > 0.01) & np.isfinite(magnitude)
    u, v, magnitude = moves[valid, 0], moves[valid, 1], magnitude[valid]
    if scale == 0:
        moving = magnitude[magnitude > 0]
        scale = float(np.percentile(moving, 95)) if moving.size else 1.0
    fk = (np.arctan2(-v, -u) / np.float32(np.pi) + 1) * np.float32((len(_WHEEL) - 1) / 2)
    k0 = fk.astype(np.int32)
    k1 = np.where(k0 + 1 == len(_WHEEL), 0, k0 + 1)
    f = (fk - k0)[:, None]
    wheel = (1 - f) * _WHEEL[k0] + f * _WHEEL[k1]
    rad = np.minimum(magnitude / np.float32(scale), 1)[:, None]
    fade = np.minimum(coverage[valid], 1)[:, None]
    colors = np.zeros(moves.shape[:-1] + (3,), dtype=np.uint8)
    colors[valid] = 255 * fade * (1 - rad * (1 - wheel))
    return colors, scale


def draw_flow_arrows(image: np.ndarray, flow: np.ndarray, coverage: np.ndarray, colors: np.ndarray,
                     step: int = 28) -> np.ndarray:
    """Draw an arrow of ``flow`` ``(H, W, 2)`` every ``step`` pixels into ``image`` ``(H, W, C)`` in place, and give it back.

    The grid starts at pixel 20. A grid pixel with ``coverage`` at 0.1 or below, or with a move under 0.5 pixels, draws
    nothing. An arrow goes from the pixel along its move, with a head a fifth of its length. All arrows draw
    3 pixels wide in a dark colour first, then each one 1 pixel wide in the colour of its pixel in ``colors``, the RGB
    ``uint8`` of :func:`flow_colors`. The colours scale to ``[0, 1]`` for a float image, and a fourth channel is made opaque.
    """
    height, width = image.shape[:2]
    full = 255.0 if np.issubdtype(image.dtype, np.integer) else 1.0

    def ink(rgb) -> np.ndarray:
        rgb = np.asarray(rgb, dtype=np.float64) * (full / 255.0)
        return np.concatenate([rgb, np.full(rgb.shape[:-1] + (1,), full)], axis=-1)[..., :image.shape[2]]

    arrows, inks = [], []
    for y in range(20, height, step):
        for x in range(20, width, step):
            move = flow[y, x].astype(np.float64)
            if coverage[y, x] <= 0.1 or math.hypot(*move) < 0.5:
                continue
            a = np.array([x, y], dtype=np.float64)
            b = np.clip(np.rint(a + move), -1e6, 1e6)
            tip, angle = 0.2 * math.hypot(*(a - b)), math.atan2(a[1] - b[1], a[0] - b[0])
            heads = (np.rint(b + tip * np.array([math.cos(angle + turn), math.sin(angle + turn)])) for turn in (math.pi / 4, -math.pi / 4))
            arrows.append(np.concatenate([_line(a, b, width, height), *(_line(h, b, width, height) for h in heads)]))
            inks.append(np.broadcast_to(colors[y, x, :3], (len(arrows[-1]), 3)))
    if arrows:
        _stamp(image, np.concatenate(arrows), 3, ink((12, 15, 20)))
        _stamp(image, np.concatenate(arrows), 1, ink(np.concatenate(inks)))
    return image


# ── Scene ─────────────────────────────────────────────────────────────────────

def _wait(done: Callable[[], bool], timeout: float, poll: float) -> bool:
    """Poll until ``done()``; ``False`` after ``timeout`` seconds. The GIL is free between the polls."""
    deadline = time.monotonic() + timeout
    while not done():
        if time.monotonic() >= deadline:
            return False
        time.sleep(poll)
    return True


class Scene:
    """A static scene (``.ply``, ``.sog``, ``.guf``) or a 4DGS video; get it from :meth:`GraciaSDK.load`.

    What a video's file carries, its cameras, point clouds and instance names, reads on first use.
    """
    __slots__ = ("_inner", "_time", "_version", "_extent", "_cameras", "_point_clouds", "_instance_names")

    def __init__(self, inner):
        self._inner = inner
        self._time = None
        self._version = 0
        self._extent = self._cameras = self._point_clouds = self._instance_names = None

    @property
    def is_video(self) -> bool:
        return isinstance(self._inner, _native.VideoStream)

    def _track(self) -> Tuple[float, float]:
        if self._extent is None:
            self._extent = self._inner.extent() if self.is_video else (0.0, 0.0)
        return self._extent

    @property
    def cameras(self) -> Tuple[SceneCamera, ...]:
        """The cameras a video carries, sorted by name; empty for every other scene. ``ValueError`` for a bad camera."""
        if self._cameras is None:
            begin, end = self._track()
            raw = sorted(self._inner.cameras(), key=lambda c: c[0]) if self.is_video else ()
            self._cameras = tuple(_scene_camera(begin, end, *c) for c in raw)
        return self._cameras

    @property
    def point_clouds(self) -> Tuple[PointCloud, ...]:
        """The point clouds a video carries, in the order the file states them; empty for every other scene."""
        if self._point_clouds is None:
            begin, end = self._track()
            raw = self._inner.point_clouds() if self.is_video else ()
            self._point_clouds = tuple(PointCloud(name, positions, begin, end) for name, positions in raw)
        return self._point_clouds

    @property
    def camera_kinds(self) -> Tuple[str, ...]:
        """The kind of each camera, in the order of :attr:`cameras`."""
        return tuple(c.kind for c in self.cameras)

    def camera(self, key: Union[int, str]) -> SceneCamera:
        """A camera by index, or by name; ``IndexError`` or ``KeyError`` when there is none."""
        if not isinstance(key, str):
            return self.cameras[key]
        for c in self.cameras:
            if c.name == key:
                return c
        raise KeyError(f"No camera named {key!r}")

    def instance_names(self) -> dict:
        """``{instance_id: name}`` of a video with segmentation; empty for every other scene."""
        if self._instance_names is None:
            self._instance_names = self._inner.instance_names() if self.is_video else {}
        return dict(self._instance_names)

    def bbox(self) -> tuple:
        """``(min_x, min_y, min_z, max_x, max_y, max_z)`` over all splats; a video first waits for :meth:`ready`."""
        self.wait_ready()
        return tuple(self._inner.bbox())

    def adaptive_bbox(self) -> tuple:
        """:meth:`bbox` with sparse outlier splats discounted, usually a tighter frame."""
        self.wait_ready()
        return tuple(self._inner.adaptive_bbox())

    def count(self) -> int:
        """The splats count; for a video, of the frame drawn last."""
        return self._inner.count()

    def set_transform(self, m: np.ndarray):
        """Set the ``(4, 4)`` column-major model-to-world transform."""
        self._inner.set_transform(np.ascontiguousarray(m, dtype=np.float32))
        self._version += 1

    def set_flag(self, k: str, v: bool):
        """Set a renderer flag: ``sh3`` for the view-dependent color, ``mip`` for the antialiasing filter.

        Every scene loads with ``mip`` on, except a video whose track clears its ``Mip`` option.
        """
        self._inner.set_flag(k, v)
        self._version += 1

    def set_uint(self, k: str, v: int):
        """Set an integer parameter: ``instance_filter`` draws instance ``v`` white over black, and ``0`` gives the colors back.

        Only a video labels its splats, see :meth:`instance_names`. The other splats still hide what is behind them.
        """
        self._inner.set_uint(k, v)
        self._version += 1

    def duration(self) -> float:
        """The length of a video in seconds; 0 for a static scene."""
        return self._inner.duration() if self.is_video else 0.0

    def set_time(self, t: float):
        """Seek a video to ``t`` seconds; the data arrives over later ticks. A :class:`View` seeks its scenes itself."""
        if self.is_video and t != self._time:
            self._inner.set_time(t)
            self._time = t

    def ready(self) -> bool:
        """Whether a video has decoded its first frame; it stays ``True`` after a seek. Always ``True`` for a static scene."""
        return not self.is_video or self._inner.ready()

    def is_buffering(self) -> bool:
        """Whether a video has no data for its current time. Always ``False`` for a static scene."""
        return self.is_video and self._inner.is_buffering()

    def wait_ready(self, timeout: float = 30.0):
        """Block until :meth:`ready`; ``RuntimeError`` after ``timeout`` seconds."""
        if not _wait(self.ready, timeout, 0.01):
            raise RuntimeError("VideoStream timed out")

    def wait_buffered(self, timeout: float = 5.0, poll: float = 0.001) -> bool:
        """Block while :meth:`is_buffering`; ``False`` after ``timeout`` seconds, and it never raises."""
        return _wait(lambda: not self.is_buffering(), timeout, poll)


# ── View ──────────────────────────────────────────────────────────────────────

_IDENTITY = np.eye(4, dtype=np.float32)
_UNSET = object()

# Each half float to its nearest byte in [0, 1].
_HALF_TO_BYTE = np.rint(np.clip(np.nan_to_num(np.arange(65536, dtype=np.uint32).astype(np.uint16).view(np.float16).astype(np.float32)), 0, 1) * 255).astype(np.uint8)


def _unweighted(weighted: np.ndarray, coverage: np.ndarray) -> np.ndarray:
    """``weighted`` ``(H, W, C)`` divided by ``coverage`` ``(H, W)``, and 0 under the renderer's own threshold of ``1/255``."""
    out = np.zeros(weighted.shape, dtype=np.float32)
    np.divide(weighted, coverage[:, :, None], out=out, where=coverage[:, :, None] >= 1.0 / 255.0)
    return out


class View:
    """Scenes seen from a camera at a time, at a size: each output renders when read, and holds until the view changes.

    Set a field, for example ``view.time = 1.5``, and the next read renders for it; an output that is not read does
    not render. ``camera`` is a :class:`CameraSetup`, or a :class:`SceneCamera` taken at :attr:`time`. A change to a
    scene, such as :meth:`Scene.set_uint`, also renders again.

    ``wait`` is the seconds each read waits for the data of a video's time: ``True`` is 5, and ``False`` draws what has
    decoded. A video first waits for its first frame, ``RuntimeError`` after 30 seconds. A timeout of the second wait
    never raises, and :attr:`buffering` reports it.
    """
    __slots__ = ("_sdk", "_cache", "scenes", "camera", "width", "height", "time", "model_transform", "wait")

    def __init__(self, sdk: "GraciaSDK", scenes: Union[Scene, Sequence[Scene]], camera: Union[CameraSetup, SceneCamera],
                 width: int, height: int, time: float = 0.0, model_transform: Optional[np.ndarray] = None,
                 wait: Union[bool, float] = True):
        object.__setattr__(self, "_sdk", sdk)
        object.__setattr__(self, "_cache", {})
        self.scenes, self.camera, self.width, self.height = scenes, camera, width, height
        self.time, self.model_transform, self.wait = time, model_transform, wait

    def __setattr__(self, name: str, value):
        if name == "scenes":
            value = (value,) if isinstance(value, Scene) else tuple(value)
        elif name == "model_transform" and value is not None:
            value = np.ascontiguousarray(value, dtype=np.float32)
        old = getattr(self, name, _UNSET)
        if old is value or (name in ("width", "height", "time", "wait", "scenes") and old == value):
            return
        object.__setattr__(self, name, value)
        self._cache.clear()

    @property
    def camera_setup(self) -> CameraSetup:
        """The camera at :attr:`time`."""
        return self.camera.at(self.time) if isinstance(self.camera, SceneCamera) else self.camera

    @property
    def buffering(self) -> bool:
        """``True`` when a read since the last change had no data for its time: it shows an earlier time, or nothing."""
        return self._cache.get("buffering", False)

    @property
    def color(self) -> np.ndarray:
        """RGBA ``float16`` ``(H, W, 4)`` in ``[0, 1]``. Its alpha is 1 everywhere: use :attr:`coverage` as the mask."""
        return self._get("color", lambda: self._draw(self._sdk._native.color).view(np.float16))

    @property
    def color8(self) -> np.ndarray:
        """RGBA ``uint8`` ``(H, W, 4)``, :attr:`color` rounded to bytes, the way to show it."""
        return self._get("color8", lambda: _HALF_TO_BYTE[self.color.view(np.uint16)])

    @property
    def depth(self) -> np.ndarray:
        """``float32`` ``(H, W)``: the view-space Z of the splats, weighted by what each adds to the color; negative in front, 0 under ``1/255`` coverage."""
        return self._depth()[0]

    @property
    def coverage(self) -> np.ndarray:
        """``float32`` ``(H, W)`` in ``[0, 1]``: the accumulated opacity, read with :attr:`depth`. Multiply a normalized depth by it for display."""
        return self._depth()[1]

    @property
    def points(self) -> Tuple[Tuple[PointCloud, np.ndarray], ...]:
        """Each point cloud of the scenes with its ``(N, 3)`` points at :attr:`time`."""
        return self._get("points", lambda: tuple((c, c.at(self.time)) for s in self.scenes for c in s.point_clouds))

    def flow(self, reference_time: float) -> Optional[FlowResult]:
        """The flow of each splat from :attr:`time` to ``reference_time``, both in seconds; ``None`` when no scene has flow.

        Each video goes to ``reference_time``, waits, and a flow frame prepares with nothing drawn, seen from the camera
        at ``reference_time``. Then each video goes back to :attr:`time`, waits again, and a flow frame draws against the
        first one, seen from the camera at :attr:`time`. Each position is seen from the camera of its own time, thus a
        dynamic camera that moves adds flow, and a static scene in front of it moves too. Only a video whose splats
        carry ids has flow. ``ValueError`` when a video gets the same two times: a flow frame at the time of the one
        before keeps that one's reference.
        """
        if any(s.is_video for s in self.scenes) and reference_time == self.time:
            raise ValueError("flow needs a reference_time other than the view's time")

        def make() -> Optional[FlowResult]:
            native = self._sdk._native.flow
            self._draw(native, reference_time, False)
            raw = self._draw(native, self.time, True)
            if raw is None:
                return None
            raw = raw.view(np.float32)
            coverage = np.ascontiguousarray(raw[:, :, 3])
            return FlowResult(_unweighted(raw[:, :, :2], coverage), coverage, self.buffering)

        return self._get(("flow", reference_time), make)

    def _get(self, key, make):
        """The output under ``key``, made once for the scenes as they are now."""
        versions = tuple(s._version for s in self.scenes)
        if self._cache.get("versions") != versions:
            self._cache.clear()
            self._cache["versions"] = versions
        if key not in self._cache:
            self._cache[key] = make()
        return self._cache[key]

    def _depth(self) -> Tuple[np.ndarray, np.ndarray]:
        def make():
            raw = self._draw(self._sdk._native.depth).view(np.float32)
            coverage = np.ascontiguousarray(raw[:, :, 1])
            return _unweighted(raw[:, :, :1], coverage)[:, :, 0], coverage
        return self._get("depth", make)

    def _draw(self, native: Callable, *args):
        """Seek each video to the time, wait as the view states, then call ``native`` with the scenes and the camera."""
        at = self.time if not args else args[0]
        extra = () if not args else args[1:]
        for s in self.scenes:
            s.set_time(at)
            if self.wait is not False:
                s.wait_ready()
                if not s.wait_buffered(5.0 if self.wait is True else float(self.wait)):
                    self._cache["buffering"] = True
        camera = self.camera.at(at) if isinstance(self.camera, SceneCamera) else self.camera
        model = _IDENTITY if self.model_transform is None else self.model_transform
        return native([s._inner for s in self.scenes], camera.projection, camera.camera_transform, model,
                      int(self.width), int(self.height), *extra)


# ── GraciaSDK ────────────────────────────────────────────────────────────────

class GraciaSDK:
    """The GPU context and the renderer: make it once, then load scenes and look at them through views."""
    __slots__ = ("_native",)

    def __init__(self, max_splats_count: int = 16_000_000):
        """``max_splats_count`` bounds the splats of one render, over all its scenes."""
        self._native = _native.GraciaSDK(max_splats_count)

    def load(self, path: str) -> Scene:
        """Load ``.ply``, ``.sog`` and ``.guf`` as a static scene, and every other file as a video; ``RuntimeError`` if it does not load."""
        return Scene(self._native.load(path))

    def view(self, scenes: Union[Scene, Sequence[Scene]], camera: Union[CameraSetup, SceneCamera], width: int, height: int,
             time: float = 0.0, model_transform: Optional[np.ndarray] = None, wait: Union[bool, float] = True) -> View:
        """A :class:`View` of one scene, or several in one frame; ``model_transform`` places all of them."""
        return View(self, scenes, camera, width, height, time, model_transform, wait)
