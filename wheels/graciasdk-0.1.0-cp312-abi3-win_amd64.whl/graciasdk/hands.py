"""The hands of a video: the keypoints of the hands, their SOMA-X hand models and the confidence of the keypoints, which a
video carries as series.

The series are drafts, and their form can change. The joints and the confidence need NumPy alone. A mesh and the keypoints
of the model also need SOMA-X from https://github.com/NVlabs/SOMA-X, which runs on the CPU and downloads the assets of the
model the first time.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Optional, Sequence, Tuple

import numpy as np

if TYPE_CHECKING:
    from . import Series

_AGGREGATES = {"mean": np.mean, "median": np.median, "min": np.min, "max": np.max}

CONFIDENCE_AGGREGATES = (*_AGGREGATES, "seen")
FINGERTIPS = (4, 8, 12, 16, 20)
"""The tips of the thumb, index, middle, ring and little fingers, in the order of ``HAND_EDGES``."""

_MODELS = ("soma_hands/", "hand_models")
_CONFIDENCE = ("hand_keypoint_confidence/", "hand_keypoint_confidence")
_VERSION = 2
_KEYPOINTS = 21
_SOMA_KEYPOINTS = [0, 1, 2, 3, 4, 6, 7, 8, 9, 11, 12, 13, 14, 16, 17, 18, 19, 21, 22, 23, 24]


def _series_of(series: Sequence[Series], kind: Tuple[str, str]) -> dict:
    """The series whose name starts with the prefix of ``kind`` and whose values state its format of this version, by the
    name of the hand."""
    prefix, form = kind
    return {s.name[len(prefix):]: s for s in series
            if s.name.startswith(prefix) and s.values.get("format") == form and s.values.get("version") == _VERSION}


def _axis_angles(quaternions: np.ndarray) -> np.ndarray:
    """The axis-angle vectors ``(..., 3)`` of unit quaternions ``(..., 4)`` ``(x, y, z, w)``, each turn of half a circle at most."""
    q = np.asarray(quaternions, dtype=np.float64)
    q = np.where(q[..., 3:] < 0.0, -q, q)
    length = np.linalg.norm(q[..., :3], axis=-1, keepdims=True)
    angle = 2.0 * np.arctan2(length, q[..., 3:])
    return (np.where(length < 1e-8, 2.0, angle / np.where(length < 1e-8, 1.0, length)) * q[..., :3]).astype(np.float32)


@dataclass(frozen=True, slots=True)
class HandShape:
    """What stays the same over one chunk of a hand."""
    side: str
    """``"left"`` or ``"right"``."""
    identity: np.ndarray
    """``(20,)`` the shape coefficients of the model."""
    scale: float
    """Scene units for each meter."""
    bones: np.ndarray
    """``(24,)`` the length of each bone in scene units, in the order of :attr:`HandPose.articulation`."""
    bone_scales: Optional[np.ndarray] = None
    """``(24,)`` the scale of each bone length of the model, where the series states them."""


@dataclass(frozen=True, slots=True)
class HandPose:
    """A hand at one time, as SOMA-X takes it: each rotation an axis angle."""
    shape: HandShape
    articulation: np.ndarray
    """``(24, 3)`` each finger joint, relative to the bind pose of the model."""
    rotation: np.ndarray
    """``(3,)`` the wrist frame of the model in the scene."""
    translation: np.ndarray
    """``(3,)`` the wrist joint in the scene."""


class SomaPoser:
    """SOMA-X: the ``SOMAHandLayer`` of https://github.com/NVlabs/SOMA-X, on the CPU, for the ``model`` that the values of a
    series name. It reads the assets of the model, and downloads them the first time."""

    def __init__(self, model: dict):
        from soma.assets import get_assets_dir

        self._root = get_assets_dir(revision=model["assets"].rpartition("@")[2])
        self._lod = model["lod"]
        self._layers: dict = {}
        self._prepared: dict = {}

    def _layer(self, side: str):
        if side not in self._layers:
            from soma import SOMAHandLayer

            self._layers[side] = SOMAHandLayer(data_root=self._root, hand_type=side, device="cpu", mode="torch", lod=self._lod,
                                               correctives_model_path=None)
        return self._layers[side]

    def faces(self, side: str) -> np.ndarray:
        """``(T, 3)`` the faces of the mesh of a side."""
        return self._layer(side).faces.numpy()

    def _posed(self, pose: HandPose, fk_only: bool = False):
        """The output of the model for one pose, in scene units: joint 0 of the model takes the rotation of the wrist."""
        import torch

        shape = pose.shape
        layer = self._layer(shape.side)
        with torch.no_grad():
            prepared = (shape.identity.tobytes(), shape.scale, None if shape.bone_scales is None else shape.bone_scales.tobytes())
            if self._prepared.get(shape.side) != prepared:
                layer.prepare_identity(torch.from_numpy(shape.identity)[None],
                                       None if shape.bone_scales is None else torch.from_numpy(shape.bone_scales)[None],
                                       global_scale=shape.scale)
                self._prepared[shape.side] = prepared
            poses = torch.from_numpy(np.concatenate((pose.rotation[None], pose.articulation)).astype(np.float32))[None]
            return layer.pose(poses, global_translation=torch.from_numpy(np.asarray(pose.translation, dtype=np.float32))[None],
                              fk_only=fk_only, reference_pose=layer.bind_pose_world[:, :3, :3])

    def mesh(self, pose: HandPose) -> np.ndarray:
        """``(V, 3)`` the vertices of the posed model in the scene."""
        return self._posed(pose).vertices[0].numpy()

    def keypoints(self, pose: HandPose) -> np.ndarray:
        """``(21, 3)`` the joints of the posed model that match the hand keypoints, in the scene, in the order of ``HAND_EDGES``."""
        return self._posed(pose, fk_only=True).joints[0].numpy()[_SOMA_KEYPOINTS]


class HandModels:
    """The SOMA-X hands of a video: get them from :attr:`Scene.hand_models`.

    Each hand has one series, by the name of the hand: the series of its points has the same name. Each value is in the
    coordinates of the track, as the series are. A time that no chunk of a hand plays has no data of the hand.
    """
    __slots__ = ("model", "series", "_poser")

    def __init__(self, model: dict, series: dict):
        self.model = model
        """The model that poses the hands, as the values of the series state it."""
        self.series = series
        """The series of each hand, by the name of the hand."""
        self._poser: Optional[SomaPoser] = None

    @property
    def hands(self) -> Tuple[str, ...]:
        return tuple(self.series)

    @property
    def poser(self) -> SomaPoser:
        """The poser of the model, made at the first use: it needs SOMA-X."""
        if self._poser is None:
            self._poser = SomaPoser(self.model)
        return self._poser

    def joints_at(self, hand: str, time: float) -> np.ndarray:
        """``(21, 3)`` the joints that the series stores at ``time`` seconds, in the order of ``HAND_EDGES``, NaN with no data.

        Between two samples each joint moves along a line. It needs no model.
        """
        values = self.series[hand].at(time)
        return np.full((_KEYPOINTS, 3), np.nan, dtype=np.float32) if values is None else values["joints"]

    def pose_at(self, hand: str, time: float) -> Optional[HandPose]:
        """The pose of a hand at ``time`` seconds, ``None`` with no data.

        Between two samples the rotations turn along the shorter arc and the translation moves along a line.
        """
        values = self.series[hand].at(time)
        if values is None or np.isnan(values["rotation"]).any():
            return None
        shape = HandShape(self.series[hand].values["side"], values["identity"], float(values["scale"][0]), values["bones"],
                          values.get("bone_scales"))
        return HandPose(shape, _axis_angles(values["articulation"]), _axis_angles(values["rotation"]), values["translation"])

    def times(self, hand: str) -> np.ndarray:
        """``(N,)`` the seconds of the samples of a hand, each once, in order."""
        return np.unique(np.concatenate([chunk.times for chunk in self.series[hand].samples()]))

    def mesh_at(self, hand: str, time: float) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        """``(V, 3)`` the vertices and ``(T, 3)`` the faces of the posed model at ``time`` seconds, ``None`` with no data."""
        pose = self.pose_at(hand, time)
        return None if pose is None else (self.poser.mesh(pose), self.poser.faces(pose.shape.side))

    def keypoints_at(self, hand: str, time: float) -> np.ndarray:
        """``(21, 3)`` the keypoints of the posed model at ``time`` seconds, in the order of ``HAND_EDGES``, NaN with no data."""
        pose = self.pose_at(hand, time)
        return np.full((_KEYPOINTS, 3), np.nan) if pose is None else self.poser.keypoints(pose)

    def keypoint_track(self, hand: str) -> Tuple[np.ndarray, np.ndarray]:
        """``(N,)`` the seconds of the samples of a hand, and ``(N, 21, 3)`` the keypoints of the posed model at them, NaN
        where a sample has no data."""
        times = self.times(hand)
        return times, np.stack([self.keypoints_at(hand, time) for time in times])


class KeypointConfidence:
    """How well the cameras saw each keypoint of the hands: get it from :attr:`Scene.keypoint_confidence`."""
    __slots__ = ("series",)

    def __init__(self, series: dict):
        self.series = series
        """The series of each hand, by the name of the hand."""

    @property
    def hands(self) -> Tuple[str, ...]:
        return tuple(self.series)

    def at(self, hand: str, time: float) -> np.ndarray:
        """``(21,)`` the confidence of the keypoints of a hand at ``time`` seconds, in the order of ``HAND_EDGES``, NaN with no
        data.

        Between two samples each value moves along a line. A time that two chunks share reads the later chunk.
        """
        values = self.series[hand].at(time) if hand in self.series else None
        return np.full(_KEYPOINTS, np.nan, dtype=np.float32) if values is None else values["confidence"]

    def at_times(self, hand: str, times: Sequence[float]) -> np.ndarray:
        """``(N, 21)`` the confidence of a hand at each of ``times`` in seconds."""
        return np.stack([self.at(hand, time) for time in times]) if len(times) else np.empty((0, _KEYPOINTS), dtype=np.float32)


def hand_keypoints_of(series: Sequence[Series]) -> Tuple[Series, ...]:
    """The series whose values state an OpenPose hand, and whose ``positions`` hold its 21 keypoints, F32 ``(21, 3)``."""
    return tuple(s for s in series if s.values.get("format") == "openpose_hand"
                 and any((name, dtype, tuple(shape)) == ("positions", "F32", (_KEYPOINTS, 3)) for name, dtype, shape, _ in s.attributes))


def hand_models_of(series: Sequence[Series]) -> Optional[HandModels]:
    """The hand models of the series of a video, ``None`` where they hold none."""
    hands = _series_of(series, _MODELS)
    return HandModels(next(iter(hands.values())).values["model"], hands) if hands else None


def keypoint_confidence_of(series: Sequence[Series]) -> Optional[KeypointConfidence]:
    """The keypoint confidence of the series of a video, ``None`` where they hold none."""
    hands = _series_of(series, _CONFIDENCE)
    return KeypointConfidence(hands) if hands else None


def hand_confidence(values: np.ndarray, aggregate: str = "mean") -> np.ndarray:
    """One confidence of a hand from the confidence of its keypoints, the last axis of ``values``: ``(21,)`` gives a number,
    and ``(F, 21)`` one for each frame.

    ``aggregate`` is one of :data:`CONFIDENCE_AGGREGATES`: the ``"mean"``, ``"median"``, ``"min"`` or ``"max"`` of the values,
    where a keypoint that no camera saw counts as 0, or ``"seen"``, the share of the values above 0. Give a selection of the
    keypoints, such as ``values[..., FINGERTIPS]``, to aggregate them alone. A row with NaN gives NaN.
    """
    values = np.asarray(values, dtype=np.float32)
    if aggregate == "seen":
        return np.where(np.isnan(values).any(axis=-1), np.nan, (values > 0).mean(axis=-1)).astype(np.float32)[()]
    if aggregate not in _AGGREGATES:
        raise ValueError(f"expected one of {CONFIDENCE_AGGREGATES}, got {aggregate!r}")
    return _AGGREGATES[aggregate](values, axis=-1)
